from pyamaze import maze, agent, COLOR, textLabel
from queue import PriorityQueue

def h(cell1, cell2):
    x1, y1 = cell1
    x2, y2 = cell2
    return abs(x1 - x2) + abs(y1 - y2)

def aStar(myMaze, start=None):
    if start is None:
        start = (myMaze.rows, myMaze.cols)

    open = PriorityQueue()
    open.put((h(start, myMaze._goal), h(start, myMaze._goal), start))

    aPath = {}
    g_score = {row: float("inf") for row in myMaze.grid}
    g_score[start] = 0
    f_score = {row: float("inf") for row in myMaze.grid}
    f_score[start] = h(start, myMaze._goal)

    searchPath = [start]

    while not open.empty():
        currCell = open.get()[2]
        searchPath.append(currCell)

        if currCell == myMaze._goal:
            break

        for d in 'ESNW':
            if myMaze.maze_map[currCell][d] == True:
                if d == 'E':
                    childCell = (currCell[0], currCell[1] + 1)
                elif d == 'W':
                    childCell = (currCell[0], currCell[1] - 1)
                elif d == 'N':
                    childCell = (currCell[0] - 1, currCell[1])
                elif d == 'S':
                    childCell = (currCell[0] + 1, currCell[1])

                temp_g_score = g_score[currCell] + 1
                temp_f_score = temp_g_score + h(childCell, myMaze._goal)

                if temp_f_score < f_score[childCell]:
                    aPath[childCell] = currCell
                    g_score[childCell] = temp_g_score
                    f_score[childCell] = temp_g_score + h(childCell, myMaze._goal)
                    open.put((f_score[childCell], h(childCell, myMaze._goal), childCell))

    fwdPath = {}
    cell = myMaze._goal
    while cell != start:
        fwdPath[aPath[cell]] = cell
        cell = aPath[cell]

    return searchPath, aPath, fwdPath

if __name__ == '__main__':
    myMaze = maze(4, 4)
    myMaze.CreateMaze(loadMaze='aStardemo.csv')

    # Set the title using the .title attribute
    myMaze.title = 'MAZE GAME'

    searchPath, aPath, fwdPath = aStar(myMaze)
    a = agent(myMaze, footprints=True, color=COLOR.blue, filled=True)
    b = agent(myMaze, 1, 1, footprints=True, color=COLOR.yellow, filled=True, goal=(myMaze.rows, myMaze.cols))
    c = agent(myMaze, footprints=True, color=COLOR.red)

    myMaze.tracePath({a: searchPath}, delay=300)
    myMaze.tracePath({b: aPath}, delay=300)
    myMaze.tracePath({c: fwdPath}, delay=300)

    l = textLabel(myMaze, 'MAZE GAME - A Star Path Length', len(fwdPath) + 1)
    l = textLabel(myMaze, 'MAZE GAME - A Star Search Length', len(searchPath))
    myMaze.run()
